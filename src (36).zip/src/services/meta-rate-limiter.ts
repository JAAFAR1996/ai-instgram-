/**
 * ===============================================
 * Meta Rate Limiter & Header Monitor (2025 Standards)
 * ✅ مراقبة استخدام الـ API وتطبيق Backoff ذكي
 * ===============================================
 */

import { RATE_LIMITS } from '../config/graph-api.js';
import { getRedisConnectionManager } from './RedisConnectionManager.js';
import { RedisUsageType } from '../config/RedisConfigurationFactory.js';
import { randomUUID, randomInt } from 'crypto';
import { getLogger } from './logger.js';

export interface RateLimitStatus {
  appUsage: number;
  businessUsage: number;
  pageUsage: number;
  adsUsage: number;
  timestamp: number;
}

export interface BackoffState {
  isBackingOff: boolean;
  backoffUntil: number;
  backoffDurationMs: number;
  reason: string;
}

export class MetaRateLimiter {
  private currentUsage: RateLimitStatus = {
    appUsage: 0,
    businessUsage: 0,
    pageUsage: 0,
    adsUsage: 0,
    timestamp: Date.now()
  };

  private backoffState: BackoffState = {
    isBackingOff: false,
    backoffUntil: 0,
    backoffDurationMs: 0,
    reason: ''
  };

  private redis = getRedisConnectionManager();
  private logger = getLogger({ component: 'MetaRateLimiter' });
  private memoryStore?: Map<string, Array<{ timestamp: number; id: string }>>;

  /**
   * Process rate limit headers from Meta API response
   */
  processRateLimitHeaders(headers: Headers): void {
    const now = Date.now();

    // Parse usage headers
    const appUsageHeader = headers.get('X-App-Usage');
    const businessUsageHeader = headers.get('X-Business-Use-Case-Usage');
    const pageUsageHeader = headers.get('X-Page-Usage');
    const adsUsageHeader = headers.get('X-Ads-Usage');

    // Update current usage
    this.currentUsage = {
      appUsage: this.parseUsageHeader(appUsageHeader, 'call_count'),
      businessUsage: this.parseUsageHeader(businessUsageHeader, 'call_count'),
      pageUsage: this.parseUsageHeader(pageUsageHeader, 'call_count'),
      adsUsage: this.parseUsageHeader(adsUsageHeader, 'call_count'),
      timestamp: now
    };

    // Check if we need to enter backoff mode
    this.evaluateBackoffNeed();
  }

  /**
   * Check if we should back off before making request
   */
  shouldBackOff(): BackoffState {
    const now = Date.now();
    
    // Check if current backoff is still active
    if (this.backoffState.isBackingOff && now < this.backoffState.backoffUntil) {
      return this.backoffState;
    }

    // Clear expired backoff
    if (this.backoffState.isBackingOff && now >= this.backoffState.backoffUntil) {
      this.backoffState = {
        isBackingOff: false,
        backoffUntil: 0,
        backoffDurationMs: 0,
        reason: ''
      };
    }

    return this.backoffState;
  }

  /**
   * Get current usage status
   */
  getCurrentUsage(): RateLimitStatus {
    return { ...this.currentUsage };
  }

  /**
   * Force backoff (for 429 responses)
   */
  forceBackoff(durationMs: number = RATE_LIMITS.BACKOFF_BASE_MS, reason: string = '429_response'): void {
    const jitter = randomInt(0, RATE_LIMITS.JITTER_MS);
    const actualDuration = Math.min(durationMs + jitter, RATE_LIMITS.BACKOFF_MAX_MS);

    this.backoffState = {
      isBackingOff: true,
      backoffUntil: Date.now() + actualDuration,
      backoffDurationMs: actualDuration,
      reason
    };

    this.logger.warn(`Meta API backoff activated: ${reason} for ${Math.round(actualDuration/1000)}s`);
  }

  /**
   * Wait for backoff to complete
   */
  async waitForBackoff(): Promise<void> {
    const backoff = this.shouldBackOff();
    
    if (backoff.isBackingOff) {
      const waitTime = backoff.backoffUntil - Date.now();
      
      if (waitTime > 0) {
        this.logger.info(`Waiting ${Math.round(waitTime/1000)}s for Meta API backoff...`);
        await new Promise(resolve => setTimeout(resolve, waitTime));
      }
    }
  }

  /**
   * Get recommendations based on current usage
   */
  getUsageRecommendations(): {
    shouldReduce: boolean;
    recommendations: string[];
    criticalThresholds: string[];
  } {
    const recommendations: string[] = [];
    const criticalThresholds: string[] = [];
    let shouldReduce = false;

    // Check app usage
    if (this.currentUsage.appUsage > RATE_LIMITS.APP_USAGE_THRESHOLD) {
      shouldReduce = true;
      if (this.currentUsage.appUsage > 90) {
        criticalThresholds.push(`App usage at ${this.currentUsage.appUsage}% - CRITICAL`);
      } else {
        recommendations.push(`App usage at ${this.currentUsage.appUsage}% - consider reducing requests`);
      }
    }

    // Check business usage
    if (this.currentUsage.businessUsage > RATE_LIMITS.BUSINESS_USAGE_THRESHOLD) {
      shouldReduce = true;
      if (this.currentUsage.businessUsage > 90) {
        criticalThresholds.push(`Business usage at ${this.currentUsage.businessUsage}% - CRITICAL`);
      } else {
        recommendations.push(`Business usage at ${this.currentUsage.businessUsage}% - consider reducing requests`);
      }
    }

    return {
      shouldReduce,
      recommendations,
      criticalThresholds
    };
  }

  /**
   * Parse usage header JSON
   */
  private parseUsageHeader(headerValue: string | null, field: string): number {
    if (!headerValue) return 0;

    try {
      const usage = JSON.parse(headerValue);
      return usage[field] || 0;
    } catch (error) {
      this.logger.warn(`Failed to parse usage header: ${headerValue}`);
      return 0;
    }
  }

  /**
   * Evaluate if we need to enter backoff mode
   */
  private evaluateBackoffNeed(): void {
    const { shouldReduce, criticalThresholds } = this.getUsageRecommendations();

    // If we're already in critical territory, force backoff
    if (criticalThresholds.length > 0) {
      const duration = RATE_LIMITS.BACKOFF_BASE_MS * 2; // Double duration for critical
      this.forceBackoff(duration, `Critical thresholds: ${criticalThresholds.join(', ')}`);
      return;
    }

    // If we should reduce but not critical, enter shorter backoff
    if (shouldReduce) {
      this.forceBackoff(RATE_LIMITS.BACKOFF_BASE_MS, 'High usage detected');
    }
  }

  /**
   * Redis-based sliding window rate limiter
   */
  async checkRedisRateLimit(
    key: string,
    windowMs: number,
    maxRequests: number
  ): Promise<{ allowed: boolean; remaining: number; resetTime: number }> {
    try {
      const redis = await this.redis.getConnection(RedisUsageType.RATE_LIMITER);
      const now = Date.now();
      const windowStart = now - windowMs;
      const windowKey = `rate_limit:${key}:${Math.floor(now / windowMs)}`;
      
      // Remove old entries and add current request
      const multi = redis.multi();
      multi.zremrangebyscore(windowKey, 0, windowStart);
      multi.zadd(windowKey, now, `${now}-${randomUUID()}`);
      multi.zcard(windowKey);
      multi.expire(windowKey, Math.ceil(windowMs / 1000) + 1);
      
      const results = await multi.exec();
      const countEntry = Array.isArray(results?.[2]) ? results?.[2][1] : 0;
      const currentCount = typeof countEntry === 'number' ? countEntry : Number(countEntry) || 0;
      
      return {
        allowed: currentCount <= maxRequests,
        remaining: Math.max(0, maxRequests - currentCount),
        resetTime: now + windowMs
      };
    } catch (error) {
      this.logger.warn('Redis rate limiter failed, falling back to memory', { error });
      return this.memoryFallback(key, windowMs, maxRequests);
    }
  }

  /**
   * Unified Graph API request handler with rate limiting and backoff
   */
  async graphRequest(
    url: string,
    options: RequestInit,
    rateKey: string,
    windowMs: number = 60_000,
    maxRequests: number = 90,
    retries: number = 5
  ): Promise<Response> {
    let attempt = 0;
    while (attempt < retries) {
      attempt++;
      try {
        const check = await this.checkRedisRateLimit(rateKey, windowMs, maxRequests);
        if (!check.allowed) {
          this.logger.error(
            `Meta rate limiter blocked request: ${rateKey} (remaining: ${check.remaining})`
          );
          const err: any = new Error('RATE_LIMIT_EXCEEDED');
          err.code = 'RATE_LIMIT_EXCEEDED';
          err.resetTime = check.resetTime;
          throw err;
        }

        // Use enhanced fetch that respects Meta backoff headers
        return await fetchWithRateLimit(url, options, retries - attempt);
      } catch (error) {
        this.logger.error(`graphRequest attempt ${attempt} failed:`, error);
        if (attempt >= retries) {
          throw error;
        }
      }
    }

    // Should never reach here
    throw new Error('Graph request failed after maximum retries');
  }

  /**
   * In-memory rate limiting fallback when Redis is unavailable
   */
  private memoryFallback(key: string, windowMs: number, maxRequests: number): {
    allowed: boolean;
    remaining: number;
    resetTime: number;
  } {
    const now = Date.now();
    const windowStart = now - windowMs;
    
    // Use a simple in-memory store for rate limiting
    if (!this.memoryStore) {
      this.memoryStore = new Map<string, Array<{ timestamp: number; id: string }>>();
    }
    
    // Clean up old entries
    const entries = this.memoryStore.get(key) || [];
    const validEntries = entries.filter(entry => entry.timestamp >= windowStart);
    
    // Check if we're within limits
    const currentCount = validEntries.length;
    const allowed = currentCount < maxRequests;
    
    if (allowed) {
      // Add current request
      validEntries.push({
        timestamp: now,
        id: randomUUID()
      });
      this.memoryStore.set(key, validEntries);
    }
    
    // Clean up expired entries periodically
    if (Math.random() < 0.1) { // 10% chance to clean up
      this.cleanupMemoryStore();
    }
    
    this.logger.debug('Memory fallback rate limit check', {
      key,
      currentCount,
      maxRequests,
      allowed,
      windowMs
    });
    
    return {
      allowed,
      remaining: Math.max(0, maxRequests - currentCount),
      resetTime: now + windowMs
    };
  }

  /**
   * Clean up expired entries from memory store
   */
  private cleanupMemoryStore(): void {
    if (!this.memoryStore) return;
    
    const now = Date.now();
    const maxAge = 5 * 60 * 1000; // 5 minutes
    
    for (const [key, entries] of this.memoryStore.entries()) {
      const validEntries = entries.filter(entry => now - entry.timestamp < maxAge);
      if (validEntries.length === 0) {
        this.memoryStore.delete(key);
      } else {
        this.memoryStore.set(key, validEntries);
      }
    }
  }
}

// Singleton instance
let rateLimiterInstance: MetaRateLimiter | null = null;

/**
 * Get Meta rate limiter instance
 */
export function getMetaRateLimiter(): MetaRateLimiter {
  if (!rateLimiterInstance) {
    rateLimiterInstance = new MetaRateLimiter();
  }
  return rateLimiterInstance;
}

/**
 * Enhanced fetch with rate limiting and backoff
 */
export async function fetchWithRateLimit(
  url: string,
  options: RequestInit = {},
  retries: number = 5
): Promise<Response> {
  const rateLimiter = getMetaRateLimiter();
  const logger = getLogger({ component: 'MetaRateLimiter' });

  // Wait for any active backoff
  await rateLimiter.waitForBackoff();

  try {
    const response = await fetch(url, options);

    // Process rate limit headers
    rateLimiter.processRateLimitHeaders(response.headers);

    // Handle 429 responses
    if (response.status === 429) {
      const retryAfter = response.headers.get('Retry-After');
      const backoffMs = retryAfter 
        ? parseInt(retryAfter) * 1000 
        : RATE_LIMITS.BACKOFF_BASE_MS * Math.pow(2, 4 - retries); // Exponential backoff

      rateLimiter.forceBackoff(backoffMs, '429_rate_limited');

      if (retries > 0) {
        logger.info(`Retrying request after 429, ${retries} attempts left`);
        await rateLimiter.waitForBackoff();
        return fetchWithRateLimit(url, options, retries - 1);
      }
    }

    return response;
  } catch (error) {
    if (retries > 0) {
      logger.info(`Retrying request after error, ${retries} attempts left`);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simple retry delay
      return fetchWithRateLimit(url, options, retries - 1);
    }
    throw error;
  }
}

export default MetaRateLimiter;