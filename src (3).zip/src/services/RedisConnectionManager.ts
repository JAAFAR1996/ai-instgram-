import { Redis } from 'ioredis';
import {
  RedisUsageType,
  RedisEnvironment as Environment,
  ProductionRedisConfigurationFactory,
  RedisConfiguration
} from '../config/RedisConfigurationFactory.js';
import { 
  isConnectionHealthy as healthCheck, 
  validateConnection as validateConn, 
  performHealthCheck 
} from './RedisSimpleHealthCheck.js';
import {
  RedisConnectionError,
  RedisValidationError,
  RedisErrorHandler,
  isConnectionError,
  isTimeoutError,
  RedisRateLimitError
} from '../errors/RedisErrors.js';

export interface ConnectionInfo {
  usageType: RedisUsageType;
  host?: string;
  port?: number;
  status: 'connected' | 'disconnected' | 'connecting' | 'error';
  connectedAt?: Date;
  lastError?: string;
  reconnectAttempts: number;
  healthScore: number; // 0-100
}

export interface ConnectionStats {
  totalConnections: number;
  activeConnections: number;
  errorConnections: number;
  totalReconnects: number;
  averageHealthScore: number;
  connectionsByType: Record<RedisUsageType, number>;
}

export interface ConnectionPoolConfig {
  maxConnections: number;
  connectionTimeout: number;
  healthCheckInterval: number;
  reconnectDelay: number;
  maxReconnectAttempts: number;
}

export class RedisConnectionManager {
  private connections: Map<RedisUsageType, Redis> = new Map();
  private connectionInfo: Map<RedisUsageType, ConnectionInfo> = new Map();
  private configFactory: ProductionRedisConfigurationFactory;
  
  // Redis availability flag - set to false when quota exceeded
  private redisEnabled: boolean = true;
  // Simplified health monitoring methods
  private errorHandler: RedisErrorHandler;
  private healthCheckInterval?: NodeJS.Timeout;
  private poolConfig: ConnectionPoolConfig;
  private rateLimitResetAt?: Date;
  private pauseReconnectionsUntil?: Date;
  private lastRateLimitLogTime = 0;
  private readonly RATE_LIMIT_LOG_INTERVAL_MS = 300000; // 5 minutes

  constructor(
    private redisUrl: string,
    private environment: Environment,
    private logger?: any,
    poolConfig?: Partial<ConnectionPoolConfig>
  ) {
    this.configFactory = new ProductionRedisConfigurationFactory();
    // Health monitoring integrated in this class now
    this.errorHandler = new RedisErrorHandler(logger);
    
    this.poolConfig = {
      maxConnections: 10,
      connectionTimeout: 10000,
      healthCheckInterval: 30000, // 30 ثانية
      reconnectDelay: 5000,
      maxReconnectAttempts: 3,
      ...poolConfig
    };

    // this.startHealthChecking(); // DISABLED: Using centralized health check instead
  }

  // Simple health check methods
  async isConnectionHealthy(connection: Redis, timeoutMs: number = 2000): Promise<boolean> {
    return healthCheck(connection, timeoutMs);
  }

  async validateConnection(connection: Redis): Promise<void> {
    return validateConn(connection);
  }

  async performHealthCheck(connection: Redis) {
    return performHealthCheck(connection);
  }

  /**
   * Get Redis connection for specific usage type
   */
  async getConnection(usageType: RedisUsageType): Promise<Redis> {
    // Rate limiting check
    if (!this.redisEnabled || this.isRateLimited()) {
      throw new RedisRateLimitError(
        'Redis connections paused due to rate limiting',
        { 
          retryAt: this.rateLimitResetAt
        }
      );
    }

    // Check if connection already exists and is healthy
    if (this.connections.has(usageType)) {
      const connection = this.connections.get(usageType)!;
      const info = this.connectionInfo.get(usageType);
      
      if (info?.status === 'connected') {
        // فحص سريع للصحة
        const isHealthy = await this.isConnectionHealthy(connection, 1000);
        if (isHealthy) {
          return connection;
        } else {
          // الاتصال غير صحي، إعادة الاتصال
          this.logger?.warn('Connection unhealthy, reconnecting', { usageType });
          await this.closeConnection(usageType);
        }
      }
    }

    // Create new connection
    return await this.createConnection(usageType);
  }

  /**
   * Check if Redis is currently rate limited
   */
  private isRateLimited(): boolean {
    if (!this.rateLimitResetAt) return false;
    
    const now = new Date();
    const isLimited = now < this.rateLimitResetAt;
    
    // Auto-reset if time has passed
    if (!isLimited) {
      this.rateLimitResetAt = undefined;
      this.redisEnabled = true;
    }
    
    return isLimited;
  }

  /**
   * Set rate limit reset time (usually next hour)
   */
  private setRateLimitReset(): Date {
    const resetTime = new Date();
    resetTime.setHours(resetTime.getHours() + 1, 0, 0, 0);
    this.rateLimitResetAt = resetTime;
    return resetTime;
  }

  /**
   * Get current connection statistics
   */
  getConnectionStats(): ConnectionStats {
    const stats: ConnectionStats = {
      totalConnections: this.connections.size,
      activeConnections: 0,
      errorConnections: 0,
      totalReconnects: 0,
      averageHealthScore: 0,
      connectionsByType: {} as Record<RedisUsageType, number>
    };

    let totalHealthScore = 0;
    
    for (const [usageType, info] of this.connectionInfo) {
      stats.connectionsByType[usageType] = 1;
      
      if (info.status === 'connected') {
        stats.activeConnections++;
      } else if (info.status === 'error') {
        stats.errorConnections++;
      }
      
      stats.totalReconnects += info.reconnectAttempts;
      totalHealthScore += info.healthScore;
    }

    if (this.connectionInfo.size > 0) {
      stats.averageHealthScore = Math.round(totalHealthScore / this.connectionInfo.size);
    }

    return stats;
  }

  /**
   * Create new Redis connection
   */
  private async createConnection(usageType: RedisUsageType): Promise<Redis> {
    const info: ConnectionInfo = this.connectionInfo.get(usageType) || {
      usageType,
      status: 'connecting',
      reconnectAttempts: 0,
      healthScore: 0
    };

    try {
      this.logger?.info('Creating Redis connection', { usageType });

      // Get configuration for this usage type
      const config = this.configFactory.createConfiguration(usageType, this.environment, this.redisUrl);

      // Create Redis connection
      const connection = new Redis({
        ...config,
        lazyConnect: true,
        maxRetriesPerRequest: 2,
        connectTimeout: this.poolConfig.connectionTimeout,
        enableReadyCheck: true,
        enableOfflineQueue: false
      });

      // Set up connection monitoring
      this.setupConnectionMonitoring(connection, usageType, info);

      // Connect with timeout
      await Promise.race([
        connection.connect(),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Connection timeout')), this.poolConfig.connectionTimeout)
        )
      ]);

      // Validate connection
      await this.validateConnection(connection);

      // Update connection info
      info.status = 'connected';
      info.connectedAt = new Date();
      info.lastError = undefined;
      info.healthScore = 100;

      this.connections.set(usageType, connection);

      this.logger?.info('Redis connection established successfully', {
        usageType,
        host: config.host,
        port: config.port,
        totalConnections: this.connections.size
      });

      return connection;

    } catch (error) {
      const redisError = this.errorHandler.handleError(error, {
        usageType,
        operation: 'createConnection'
      });
      
      if (redisError instanceof RedisRateLimitError) {
        const retryAt = this.setRateLimitReset();
        info.status = 'error';
        info.lastError = redisError.message;
        info.healthScore = 0;
        
        // Disable Redis integration when quota exceeded
        this.redisEnabled = false;
        
        // إيقاف محاولات إعادة الاتصال حتى إعادة تعيين الحد
        this.pauseReconnectionsUntil = retryAt;
        
        // Rate-limited logging to reduce noise
        const now = Date.now();
        if (now - this.lastRateLimitLogTime > this.RATE_LIMIT_LOG_INTERVAL_MS) {
          this.logger?.warn('Redis quota exceeded - switching to DB spool fallback', {
            usageType,
            retryAt: retryAt.toISOString()
          });
          this.lastRateLimitLogTime = now;
        }
        
        throw redisError;
      }

      info.status = 'error';
      info.lastError = redisError.message;
      info.healthScore = 0;

      this.logger?.error('Failed to create Redis connection', {
        usageType,
        error: redisError.message,
        code: redisError.code
      });

      throw new RedisConnectionError(
        `Failed to create ${usageType} connection: ${redisError.message}`,
        { usageType },
        redisError
      );
    } finally {
      this.connectionInfo.set(usageType, info);
    }
  }

  private setupConnectionMonitoring(
    connection: Redis, 
    usageType: RedisUsageType, 
    info: ConnectionInfo
  ): void {
    connection.on('connect', () => {
      info.status = 'connected';
      info.connectedAt = new Date();
      info.healthScore = 100;
      this.logger?.info('Redis connection established', { usageType });
    });

    connection.on('error', (error) => {
      info.status = 'error';
      info.lastError = error.message;
      info.healthScore = 0;
      
      this.logger?.error('Redis connection error', {
        usageType,
        error: error.message
      });
    });

    connection.on('close', () => {
      info.status = 'disconnected';
      info.healthScore = 0;
      this.logger?.warn('Redis connection closed', { usageType });
    });

    connection.on('reconnecting', () => {
      info.status = 'connecting';
      info.reconnectAttempts++;
      this.logger?.info('Redis reconnecting', { 
        usageType, 
        attempts: info.reconnectAttempts 
      });
    });
  }

  /**
   * Safe Redis operation with fallback handling
   */
  async safeRedisOperation<T>(
    operation: string,
    usageType: RedisUsageType,
    callback: (redis: Redis) => Promise<T>
  ): Promise<{ ok: boolean; result?: T; reason?: string; skipped?: boolean }> {
    
    // Check rate limiting first
    if (!this.redisEnabled || this.isRateLimited()) {
      return {
        ok: false,
        skipped: true,
        reason: 'rate_limited'
      };
    }

    try {
      const connection = await this.getConnection(usageType);
      const result = await callback(connection);
      return { ok: true, result };
    } catch (error: any) {
      const processedError = this.errorHandler.handleError(error, {
        usageType,
        operation
      });

      if (processedError instanceof RedisRateLimitError) {
        this.redisEnabled = false;
        this.setRateLimitReset();
        
        return {
          ok: false,
          skipped: true,
          reason: 'rate_limit_exceeded'
        };
      }

      return {
        ok: false,
        reason: processedError.message
      };
    }
  }

  /**
   * Close specific connection
   */
  async closeConnection(usageType: RedisUsageType): Promise<void> {
    const connection = this.connections.get(usageType);
    if (connection) {
      try {
        await connection.quit();
      } catch (error) {
        // Force disconnect if quit fails
        await connection.disconnect();
      }
      
      this.connections.delete(usageType);
      
      const info = this.connectionInfo.get(usageType);
      if (info) {
        info.status = 'disconnected';
        info.healthScore = 0;
      }
      
      this.logger?.info('Redis connection closed', { usageType });
    }
  }

  /**
   * Close all connections
   */
  async closeAllConnections(): Promise<void> {
    const closePromises = Array.from(this.connections.keys()).map(usageType => 
      this.closeConnection(usageType)
    );
    
    await Promise.allSettled(closePromises);
    
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = undefined;
    }
    
    this.logger?.info('All Redis connections closed');
  }

  /**
   * Get Redis status for monitoring
   */
  getRedisStatus() {
    return {
      enabled: this.redisEnabled,
      rateLimited: this.isRateLimited(),
      rateLimitResetAt: this.rateLimitResetAt?.toISOString(),
      connections: this.getConnectionStats(),
      connectionDetails: Array.from(this.connectionInfo.values())
    };
  }

  /**
   * Enable Redis (reset rate limiting)
   */
  enableRedis(): void {
    this.redisEnabled = true;
    this.rateLimitResetAt = undefined;
    this.pauseReconnectionsUntil = undefined;
    this.logger?.info('Redis re-enabled');
  }

  /**
   * Disable Redis temporarily
   */
  disableRedis(reason: string = 'manual'): void {
    this.redisEnabled = false;
    this.logger?.warn('Redis disabled', { reason });
  }

  /**
   * Manual health check for all connections
   */
  async performHealthCheckOnAllConnections(): Promise<void> {
    this.logger?.debug('Starting health check for all Redis connections...');
    
    const connections = Array.from(this.connections.entries());
    
    for (const [usageType, connection] of connections) {
      const info = this.connectionInfo.get(usageType);
      if (!info) continue;

      try {
        const isHealthy = await this.isConnectionHealthy(connection, 2000);
        
        if (isHealthy) {
          info.healthScore = Math.min(100, info.healthScore + 5); // تحسن تدريجي
          if (info.status === 'error') {
            info.status = 'connected';
            this.logger?.info('Connection recovered', { usageType });
          }
        } else {
          info.healthScore = Math.max(0, info.healthScore - 10); // تدهور تدريجي
          if (info.healthScore <= 20) {
            info.status = 'error';
            this.logger?.warn('Connection marked as unhealthy', { 
              usageType, 
              healthScore: info.healthScore 
            });
          }
        }
      } catch (error: any) {
        info.status = 'error';
        info.healthScore = 0;
        info.lastError = error.message;
        
        this.logger?.error('Health check failed for connection', {
          usageType,
          error: error.message
        });
      }
    }

    this.logger?.debug('Health check completed for all connections');
  }

  /**
   * Start periodic health checking (if needed)
   */
  private startHealthChecking(): void {
    if (this.healthCheckInterval) return;
    
    this.healthCheckInterval = setInterval(async () => {
      try {
        await this.performHealthCheckOnAllConnections();
      } catch (error: any) {
        this.logger?.error('Scheduled health check failed', { error: error.message });
      }
    }, this.poolConfig.healthCheckInterval);
  }
}

// Singleton instance
let connectionManager: RedisConnectionManager | null = null;

export function getRedisConnectionManager(): RedisConnectionManager {
  if (!connectionManager) {
    const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';
    const environment = (process.env.NODE_ENV === 'production') ? Environment.PRODUCTION : Environment.DEVELOPMENT;
    connectionManager = new RedisConnectionManager(redisUrl, environment);
  }
  return connectionManager;
}

export default RedisConnectionManager;

// Simple Redis client for basic operations (kept for compatibility)
let _client: Redis | null = null;

async function connectToRedis(): Promise<Redis> {
  if (_client) return _client;
  const url = process.env.REDIS_URL;
  if (!url) throw new Error('REDIS_URL missing');
  _client = new Redis(url, { lazyConnect: true, enableAutoPipelining: true });
  await _client.connect();
  return _client;
}

export function getRedis() {
  if (!_client) throw new Error('Redis not connected');
  return _client;
}

export async function closeRedis() {
  if (_client) {
    try { await _client.quit(); } catch { await _client.disconnect(); }
    _client = null;
  }
}