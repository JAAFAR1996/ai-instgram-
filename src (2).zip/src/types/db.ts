// src/types/db.ts
export interface DatabaseRow {
  [key: string]: unknown;
}

export interface MerchantRow extends DatabaseRow {
  id: string;
  name: string;
  created_at: Date;
  updated_at: Date;
  deleted_at?: Date;
}

export interface ConversationRow extends DatabaseRow {
  id: string;
  merchant_id: string;
  platform_id: string;
  platform_type: 'instagram' | 'facebook' | 'whatsapp';
  status: 'active' | 'paused' | 'archived';
  metadata: Record<string, unknown>;
  created_at: Date;
  updated_at: Date;
}

export interface MessageRow extends DatabaseRow {
  id: string;
  conversation_id: string;
  merchant_id: string;
  platform_message_id: string;
  direction: 'inbound' | 'outbound';
  content: string;
  metadata: Record<string, unknown>;
  created_at: Date;
  processed_at?: Date;
}

export interface CredentialRow extends DatabaseRow {
  id: string;
  merchant_id: string;
  platform: 'instagram' | 'facebook' | 'whatsapp';
  credential_type: 'access_token' | 'app_secret' | 'webhook_secret';
  value: string;
  expires_at?: Date;
  created_at: Date;
  updated_at: Date;
}

export interface QueueJobData {
  merchantId: string;
  [key: string]: unknown;
}

export interface InstagramWebhookPayload {
  object: 'instagram';
  entry: Array<{
    id: string;
    time: number;
    messaging?: Array<{
      sender: { id: string };
      recipient: { id: string };
      timestamp: number;
      message?: {
        mid: string;
        text?: string;
        attachments?: Array<{
          type: string;
          payload: { url: string };
        }>;
      };
    }>;
    changes?: Array<{
      field: string;
      value: {
        id: string;
        text?: string;
        media?: {
          id: string;
          media_type: 'IMAGE' | 'VIDEO' | 'CAROUSEL_ALBUM';
        };
      };
    }>;
  }>;
}

export interface DatabaseConfig {
  host: string;
  port: number;
  database: string;
  username: string;
  password: string;
  ssl?: boolean;
  max?: number;
  idleTimeoutMillis?: number;
  connectionTimeoutMillis?: number;
}