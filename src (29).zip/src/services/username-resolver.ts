import { getInstagramClient } from './instagram-api.js';
import { getLogger } from './logger.js';

const logger = getLogger({ component: 'UsernameResolver' });

/**
 * Resolve Instagram User ID from username using Business Discovery API
 * This is the official Meta way to derive ID from username
 */
export async function resolveIgIdByUsername(
  merchantId: string,
  businessAccountId: string,
  username: string
): Promise<string | null> {
  try {
    logger.info('🔍 Resolving IG ID from username', { merchantId, username });
    
    // GET /{businessAccountId}?fields=business_discovery.username({username}){id,username}
    const path = `/${businessAccountId}`;
    const fields = `business_discovery.username(${username}){id,username}`;
    
    const response = await getInstagramClient().get(merchantId, path, { fields });
    
    const id = response?.business_discovery?.id;
    
    if (id) {
      logger.info('✅ Successfully resolved IG ID', { username, igId: id });
      return id;
    } else {
      logger.warn('⚠️ No IG ID found for username', { username });
      return null;
    }
    
  } catch (error) {
    logger.error('❌ Failed to resolve IG ID from username', { 
      username, 
      error: error instanceof Error ? error.message : String(error) 
    });
    return null;
  }
}

/**
 * Batch resolve multiple usernames to IDs
 */
export async function resolveMultipleIgIdsByUsername(
  merchantId: string,
  businessAccountId: string,
  usernames: string[]
): Promise<Map<string, string>> {
  const results = new Map<string, string>();
  
  // Process in batches to avoid rate limits
  const BATCH_SIZE = 5;
  
  for (let i = 0; i < usernames.length; i += BATCH_SIZE) {
    const batch = usernames.slice(i, i + BATCH_SIZE);
    
    await Promise.allSettled(
      batch.map(async (username) => {
        const id = await resolveIgIdByUsername(merchantId, businessAccountId, username);
        if (id) {
          results.set(username, id);
        }
      })
    );
    
    // Small delay between batches
    if (i + BATCH_SIZE < usernames.length) {
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
  
  return results;
}
