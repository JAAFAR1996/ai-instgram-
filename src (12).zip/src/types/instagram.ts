// ملاحظة: هذه النسخة توسّع الأنواع لتكون متسامحة مع الكود الحالي.
// عدّلها لاحقًا لو حبيت تشدّد الفحص.

export type MessagingProduct = 'instagram';

export interface QuickReply {
  content_type: 'text';
  title: string;
  payload?: string;
  image_url?: string;
}

export interface InstagramMessagePayload {
  messaging_product: MessagingProduct; // 'instagram'
  recipient: { id: string };
  messaging_type?: 'RESPONSE' | 'UPDATE' | 'MESSAGE_TAG';
  message: {
    text?: string;
    attachment?: { type: string; payload: unknown };
    quick_replies?: QuickReply[];
  };
}

export interface InstagramAPIResponse {
  success?: boolean;
  id?: string;
  error?: string; // نخزّن رسالة خطأ كسلسلة (نحو JSON.stringfy)
}

export interface InstagramAPICredentials {
  accessToken: string;
  /** بعض الأجزاء تستخدم هذا الاسم؛ نوفّره اختيارياً */
  pageAccessToken?: string;
  /** مطلوب في عدة خدمات للـ cache */
  tokenExpiresAt?: Date;
  pageId?: string;
  businessAccountId?: string;
  webhookVerifyToken?: string;
  appSecret?: string;
}

/** بنية طلب الإرسال الداخلة في خدماتنا */
export interface SendMessageRequest {
  recipientId: string;
  content?: string; // نص أو JSON (للقوالب)
  quickReplies?: QuickReply[];
  attachment?: { type: string; payload: unknown };
  messagingType?: 'RESPONSE' | 'UPDATE' | 'MESSAGE_TAG';
}

export type SendResult = {
  success: boolean;
  messageId?: string;
  deliveryStatus: 'sent' | 'failed';
  timestamp: Date;
  error?: string;
};

/** حمولة Webhook للإنستغرام (مبسّطة) */
export interface IGWebhookPayload {
  object: 'instagram' | string;
  entry: Array<{
    id: string;
    time: number;
    changes?: unknown[];
    messaging?: unknown[];
  }>;
}

/** للمخرجات القادمة من sql<T> */
export type DatabaseRow = Record<string, unknown>;
export type DBRow<T> = T & DatabaseRow;

// أنواع مساعدة شائعة
export interface BusinessAccountInfo {
  id: string;
  username?: string; // نجعله اختياري لتفادي أخطاء التعيين
  name?: string;
  profile_picture_url?: string;
  followers_count?: number;
  media_count?: number;
}

export interface InstagramContext {
  merchantId: string;
  customerId: string;
  platform: 'instagram';
  stage: string;
  cart: Record<string, unknown>[];
  preferences: Record<string, unknown>;
  conversationHistory: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
    metadata?: Record<string, unknown>;
  }>;
  customerProfile?: {
    name?: string;
    phone?: string;
    instagram?: string;
    previousOrders: number;
    averageOrderValue: number;
    preferredCategories: string[];
    lastInteraction: Date;
  };
  merchantSettings?: {
    businessName: string;
    businessCategory: string;
    workingHours: Record<string, unknown>;
    paymentMethods: string[];
    deliveryFees: Record<string, unknown>;
    autoResponses: Record<string, unknown>;
  };
}

export interface MediaContent {
  format: string;
  originalFileName?: string;
  metadata?: {
    duration?: number;
    fileSize?: number;
    dimensions?: {
      width: number;
      height: number;
    };
    format?: string;
    originalFileName?: string;
    aiAnalysis?: {
      description?: string;
      objects?: string[];
      colors?: string[];
      text?: string;
      sentiment?: 'positive' | 'neutral' | 'negative';
      isProductImage?: boolean;
      suggestedTags?: string[];
    };
  };
}

export interface WebhookEvent {
  field: string;
  value: {
    id: string;
    media?: {
      id: string;
      media_product_type: 'feed' | 'story' | 'reels' | 'ad';
    };
  };
}

export interface JobData {
  merchantId: string;
  [key: string]: unknown;
}

export interface BullJob {
  data: JobData;
  attemptsMade?: number;
  opts?: {
    attempts?: number;
    delay?: number;
  };
}

export interface PerformanceMetrics {
  endpoint: string;
  method: string;
  responseTime: number;
  statusCode: number;
  timestamp: Date;
  merchantId?: string;
  errorMessage?: string;
}

export interface LogContext {
  merchantId?: string;
  endpoint?: string;
  event?: string;
  [key: string]: unknown;
}

export interface QualityStatus {
  status: 'EXCELLENT' | 'GOOD' | 'MEDIUM' | 'LOW' | 'CRITICAL';
}