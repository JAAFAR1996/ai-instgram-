import { z } from 'zod';
import { query as rawQuery } from '../db/index.js';

export async function q<T extends z.ZodTypeAny>(
  schema: T,
  strings: TemplateStringsArray,
  ...values: unknown[]
): Promise<z.infer<T>[]> {
  const sql = { strings, values } as any; // يلتقط tagged template من postgres/pg
  const rows = await rawQuery(sql);
  return schema.array().parse(rows);
}
