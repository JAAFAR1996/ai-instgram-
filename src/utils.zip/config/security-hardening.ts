/**
 * ===============================================
 * Security Hardening Configuration
 * Advanced security controls for production environment
 * ===============================================
 */

import { getConfig } from './environment.js';
import { getLogger } from '../services/logger.js';
import * as crypto from 'node:crypto';

const log = getLogger({ component: 'security-hardening' });

export interface SecurityHardeningConfig {
  passwordPolicy: {
    minLength: number;
    requireUppercase: boolean;
    requireLowercase: boolean;
    requireNumbers: boolean;
    requireSymbols: boolean;
    maxAge: number; // days
  };
  
  sessionSecurity: {
    sessionTimeout: number; // milliseconds
    maxConcurrentSessions: number;
    requireReauth: boolean;
    cookieSecure: boolean;
    cookieHttpOnly: boolean;
    cookieSameSite: 'strict' | 'lax' | 'none';
  };
  
  apiSecurity: {
    maxRequestsPerMinute: number;
    maxRequestSize: number; // bytes
    allowedMethods: string[];
    requiredHeaders: string[];
    blockSuspiciousUserAgents: boolean;
  };
  
  encryptionSettings: {
    algorithm: string;
    keyRotationDays: number;
    saltRounds: number;
  };
  
  auditSettings: {
    logFailedAttempts: boolean;
    logSuccessfulAuth: boolean;
    retentionDays: number;
    alertThresholds: {
      failedLogins: number;
      suspiciousRequests: number;
    };
  };
}

/**
 * Get security hardening configuration based on environment
 */
export function getSecurityHardeningConfig(): SecurityHardeningConfig {
  const config = getConfig();
  const isProduction = config.environment === 'production';

  return {
    passwordPolicy: {
      minLength: isProduction ? 12 : 8,
      requireUppercase: isProduction,
      requireLowercase: true,
      requireNumbers: isProduction,
      requireSymbols: isProduction,
      maxAge: isProduction ? 90 : 365
    },
    
    sessionSecurity: {
      sessionTimeout: isProduction ? 30 * 60 * 1000 : 60 * 60 * 1000, // 30min prod, 1hr dev
      maxConcurrentSessions: isProduction ? 3 : 10,
      requireReauth: isProduction,
      cookieSecure: isProduction,
      cookieHttpOnly: true,
      cookieSameSite: isProduction ? 'strict' : 'lax'
    },
    
    apiSecurity: {
      maxRequestsPerMinute: isProduction ? 60 : 200,
      maxRequestSize: 1024 * 1024, // 1MB
      allowedMethods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
      requiredHeaders: ['Content-Type', 'User-Agent'],
      blockSuspiciousUserAgents: isProduction
    },
    
    encryptionSettings: {
      algorithm: 'aes-256-gcm',
      keyRotationDays: isProduction ? 30 : 365,
      saltRounds: isProduction ? 12 : 10
    },
    
    auditSettings: {
      logFailedAttempts: true,
      logSuccessfulAuth: isProduction,
      retentionDays: isProduction ? 90 : 30,
      alertThresholds: {
        failedLogins: isProduction ? 5 : 10,
        suspiciousRequests: isProduction ? 10 : 50
      }
    }
  };
}

/**
 * Validate password against security policy
 */
export function validatePassword(password: string): { valid: boolean; errors: string[] } {
  const config = getSecurityHardeningConfig();
  const policy = config.passwordPolicy;
  const errors: string[] = [];

  if (password.length < policy.minLength) {
    errors.push(`Password must be at least ${policy.minLength} characters long`);
  }

  if (policy.requireUppercase && !/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }

  if (policy.requireLowercase && !/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }

  if (policy.requireNumbers && !/\d/.test(password)) {
    errors.push('Password must contain at least one number');
  }

  if (policy.requireSymbols && !/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
    errors.push('Password must contain at least one special character');
  }

  // Check for common weak passwords
  const commonPasswords = ['password', '123456', 'admin', 'user', 'guest'];
  if (commonPasswords.some(common => password.toLowerCase().includes(common))) {
    errors.push('Password contains common weak patterns');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Generate cryptographically secure random string
 */
export function generateSecureToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('hex');
}

/**
 * Generate secure session ID
 */
export function generateSessionId(): string {
  const timestamp = Date.now().toString(36);
  const randomBytes = crypto.randomBytes(16).toString('hex');
  return `sess_${timestamp}_${randomBytes}`;
}

/**
 * Hash password with salt
 */
export async function hashPassword(password: string): Promise<string> {
  const config = getSecurityHardeningConfig();
  const bcrypt = await import('bcrypt');
  return await bcrypt.hash(password, config.encryptionSettings.saltRounds);
}

/**
 * Verify password against hash
 */
export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  try {
    const bcrypt = await import('bcrypt');
    return await bcrypt.compare(password, hash);
  } catch (error) {
    log.error('Password verification error:', error);
    return false;
  }
}

/**
 * Detect suspicious user agents
 */
export function isSuspiciousUserAgent(userAgent: string): boolean {
  const suspiciousPatterns = [
    /bot/i,
    /crawler/i,
    /spider/i,
    /scraper/i,
    /wget/i,
    /curl/i,
    /python/i,
    /java/i,
    /scanner/i,
    /sqlmap/i,
    /nmap/i
  ];

  return suspiciousPatterns.some(pattern => pattern.test(userAgent));
}

/**
 * Validate request origin
 */
export function isValidOrigin(origin: string | undefined): boolean {
  if (!origin) return true; // Same-origin requests

  const config = getConfig();
  const allowedOrigins = config.security.corsOrigins;

  return allowedOrigins.some(allowed => {
    if (allowed === '*') return config.environment !== 'production';
    return origin === allowed || origin.endsWith(allowed.replace(/^https?:\/\//, ''));
  });
}

/**
 * Generate Content Security Policy nonce
 */
export function generateCSPNonce(): string {
  return crypto.randomBytes(16).toString('base64');
}

/**
 * Create secure headers for response
 */
export function getSecureHeaders(nonce?: string): Record<string, string> {
  const config = getConfig();
  const isProduction = config.environment === 'production';

  const headers: Record<string, string> = {
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'geolocation=(), microphone=(), camera=()',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    'Pragma': 'no-cache',
    'Expires': '0'
  };

  if (isProduction) {
    headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains; preload';
  }

  if (nonce) {
    const csp = [
      "default-src 'none'",
      "script-src 'self' 'unsafe-inline'",
      "style-src 'self' 'unsafe-inline'",
      "connect-src 'self' https://graph.facebook.com https://graph.instagram.com",
      "img-src 'self' data: https:",
      "font-src 'self'",
      "base-uri 'none'",
      "frame-ancestors 'none'",
      "form-action 'self'"
    ].join('; ');

    headers['Content-Security-Policy'] = csp;
  }

  return headers;
}

/**
 * Audit failed authentication attempt
 */
export function auditFailedAuth(identifier: string, ip: string, userAgent: string): void {
  const config = getSecurityHardeningConfig();
  
  if (config.auditSettings.logFailedAttempts) {
    log.warn('Failed authentication attempt', {
      identifier,
      ip,
      userAgent: userAgent.substring(0, 200), // Truncate long user agents
      timestamp: new Date().toISOString(),
      type: 'auth_failure'
    });
  }
}

/**
 * Audit successful authentication
 */
export function auditSuccessfulAuth(identifier: string, ip: string): void {
  const config = getSecurityHardeningConfig();
  
  if (config.auditSettings.logSuccessfulAuth) {
    log.info('Successful authentication', {
      identifier,
      ip,
      timestamp: new Date().toISOString(),
      type: 'auth_success'
    });
  }
}

/**
 * Check if IP should be rate limited based on failed attempts
 */
export function shouldRateLimit(ip: string, failedAttempts: number): boolean {
  const config = getSecurityHardeningConfig();
  return failedAttempts >= config.auditSettings.alertThresholds.failedLogins;
}

/**
 * Sanitize input to prevent injection attacks
 */
export function sanitizeInput(input: string): string {
  return input
    .replace(/[<>\"']/g, '') // Remove potential HTML/script tags
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+\s*=/gi, '') // Remove event handlers
    .trim()
    .substring(0, 1000); // Limit length
}

/**
 * Validate API key format
 */
export function validateApiKey(apiKey: string): boolean {
  // API keys should be at least 32 characters and contain only alphanumeric characters
  return /^[a-zA-Z0-9]{32,}$/.test(apiKey);
}

/**
 * Generate API key
 */
export function generateApiKey(): string {
  return generateSecureToken(32);
}

/**
 * Initialize security hardening
 */
export function initializeSecurityHardening(): void {
  const config = getSecurityHardeningConfig();
  
  log.info('Security hardening initialized', {
    environment: getConfig().environment,
    passwordMinLength: config.passwordPolicy.minLength,
    sessionTimeout: config.sessionSecurity.sessionTimeout,
    maxRequestsPerMinute: config.apiSecurity.maxRequestsPerMinute,
    encryptionAlgorithm: config.encryptionSettings.algorithm
  });

  // Set up global security event handlers if needed
  if (config.auditSettings.logFailedAttempts) {
    log.info('Security audit logging enabled');
  }
}