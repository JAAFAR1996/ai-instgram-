/**
 * ===============================================
 * Production-Grade AES-256-GCM Encryption Service
 * ✅ معايير 2025 - تشفير آمن للتوكنات والبيانات الحساسة
 * ===============================================
 */

import crypto from 'node:crypto';

export type HmacVerifyResult =
  | { ok: true }
  | { ok: false; reason: 'missing_params' | 'bad_format' | 'mismatch' | 'error' };

export function verifyHMACRaw(payload: Buffer, signature: string, secret: string): HmacVerifyResult {
  try {
    // 1) وجود القيم
    if (!payload || !signature || !secret) return { ok: false, reason: 'missing_params' };

    // 2) تنظيف التوقيع
    const sig = signature.startsWith('sha256=') ? signature.slice(7) : signature;

    // 3) تحقق من الصيغة: 64 hex
    if (!/^[a-f0-9]{64}$/i.test(sig)) return { ok: false, reason: 'bad_format' };

    // 4) حساب المتوقع على الـ raw payload
    const expectedHex = crypto.createHmac('sha256', secret).update(payload).digest('hex');

    // 5) مقارنة ثابتة الوقت
    const a = Buffer.from(expectedHex, 'hex');
    const b = Buffer.from(sig, 'hex');
    if (a.length !== b.length) return { ok: false, reason: 'bad_format' }; // نظرياً دائمًا 32 بايت

    const equal = crypto.timingSafeEqual(a, b);
    return equal ? { ok: true } : { ok: false, reason: 'mismatch' };
  } catch {
    return { ok: false, reason: 'error' };
  }
}

/**
 * Read raw body from Hono request (preserves exact bytes)
 *
 * Monitors the accumulated payload size while reading. If the size
 * exceeds `maxBytes` (default 1MB), the reader is cancelled and an
 * HTTP 413 error is thrown.
 */
export async function readRawBody(c: any, maxBytes = 1024 * 1024): Promise<Buffer> {
  const r = c.req.raw.body;
  if (!r) return Buffer.alloc(0);
  const reader = r.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;

  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      if (value) {
        size += value.length;
        if (size > maxBytes) {
          try { await reader.cancel(); } catch {}
          if (typeof c.throw === 'function') {
            c.throw(413, 'payload too large');
          }
          throw Object.assign(new Error('payload too large'), { status: 413 });
        }
        chunks.push(value);
      }
    }

    const out = Buffer.allocUnsafe(size);
    let off = 0;
    for (const u of chunks) {
      out.set(u, off);
      off += u.length;
    }
    return out;
  } finally {
    reader.releaseLock();
  }
}

export interface EncryptedData {
  iv: string;
  ct: string;
  tag: string;
}

export interface DecryptedData {
  data: string;
  timestamp: number;
}

export class EncryptionService {
  private readonly encryptionKey: Buffer;

  constructor(masterKey?: string) {
    const key = masterKey || process.env.ENCRYPTION_KEY;
    if (!key) {
      throw new Error('ENCRYPTION_KEY environment variable required');
    }

    // Accept either 64 hex characters (32 bytes) or 32 ASCII characters
    if (/^[0-9a-fA-F]{64}$/.test(key)) {
      this.encryptionKey = Buffer.from(key, 'hex');
    } else if (key.length === 32) {
      this.encryptionKey = Buffer.from(key, 'utf8');
    } else {
      throw new Error('ENCRYPTION_KEY must be 32 bytes (64 hex characters) or 32 ASCII characters');
    }
  }

  /**
   * Encrypt sensitive data using AES-256-GCM (Production 2025 standard)
   */
  public encrypt(plaintext: string, aad = 'v1'): EncryptedData {
    const iv = crypto.randomBytes(12); // GCM-recommended 12 bytes
    const cipher = crypto.createCipheriv('aes-256-gcm', this.encryptionKey, iv);
    cipher.setAAD(Buffer.from(aad));
    const ct = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    const tag = cipher.getAuthTag();
    
    return { 
      iv: iv.toString('hex'), 
      ct: ct.toString('hex'), 
      tag: tag.toString('hex') 
    };
  }

  /**
   * Decrypt sensitive data using AES-256-GCM
   */
  public decrypt({ iv, ct, tag }: EncryptedData, aad = 'v1'): string {
    const decipher = crypto.createDecipheriv('aes-256-gcm', this.encryptionKey, Buffer.from(iv, 'hex'));
    decipher.setAAD(Buffer.from(aad));
    decipher.setAuthTag(Buffer.from(tag, 'hex'));
    return Buffer.concat([decipher.update(Buffer.from(ct, 'hex')), decipher.final()]).toString('utf8');
  }

  /**
   * Encrypt platform tokens with metadata
   */
  public encryptToken(token: string, platform: 'whatsapp' | 'instagram', identifier: string): EncryptedData {
    const payload = JSON.stringify({
      token,
      platform,
      identifier,
      timestamp: Date.now()
    });
    return this.encrypt(payload, `token:${platform}`);
  }

  /**
   * Decrypt platform tokens
   */
  public decryptToken(encryptedPayload: EncryptedData, platform: 'whatsapp' | 'instagram'): { token: string; identifier: string; timestamp: number } {
    const decrypted = this.decrypt(encryptedPayload, `token:${platform}`);
    
    let parsed;
    try { parsed = JSON.parse(decrypted); }
    catch { throw new Error('Invalid token payload'); }
    if (
      !parsed ||
      typeof parsed.token !== 'string' ||
      typeof parsed.identifier !== 'string' ||
      typeof parsed.timestamp !== 'number'
    ) {
      throw new Error('Invalid token payload');
    }
    return parsed;
  }

  /**
   * Generate secure random string for verification tokens
   */
  public generateSecureRandom(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }

  /**
   * @deprecated Use verifyHMACRaw(payload: Buffer, signature, secret) instead
   * HMAC verification for webhooks - kept for backward compatibility
   */
  public verifyHMAC(payload: string, signature: string, secret: string): boolean {
    // Remove common prefix and validate format
    const sig = signature.startsWith('sha256=') ? signature.slice(7) : signature;
    if (!/^[a-f0-9]{64}$/i.test(sig)) return false;

    // Calculate expected HMAC
    const expectedHex = crypto.createHmac('sha256', secret).update(payload).digest('hex');

    // Compare buffers safely
    const a = Buffer.from(expectedHex, 'hex');
    const b = Buffer.from(sig, 'hex');
    if (a.length !== b.length) return false;
    return crypto.timingSafeEqual(a, b);
  }

  /**
   * Convenience methods for WhatsApp/Instagram tokens
   */
  public encryptInstagramToken(token: string): string {
    return JSON.stringify(this.encrypt(token));
  }

  public decryptInstagramToken(encryptedData: string): string {
    const data = JSON.parse(encryptedData) as EncryptedData;
    return this.decrypt(data);
  }

  public encryptWhatsAppToken(token: string): string {
    return JSON.stringify(this.encrypt(token));
  }

  public decryptWhatsAppToken(encryptedData: string): string {
    const data = JSON.parse(encryptedData) as EncryptedData;
    return this.decrypt(data);
  }
}

// Singleton instance
let encryptionInstance: EncryptionService | null = null;

/**
 * Get encryption service instance
 */
export function getEncryptionService(): EncryptionService {
  if (!encryptionInstance) {
    encryptionInstance = new EncryptionService();
  }
  return encryptionInstance;
}

// Export main functions for convenience using lazy-loaded service
export function encrypt(plaintext: string, aad?: string): EncryptedData {
  return getEncryptionService().encrypt(plaintext, aad);
}

export function decrypt(data: EncryptedData, aad?: string): string {
  return getEncryptionService().decrypt(data, aad);
}

export function encryptToken(
  token: string,
  platform: 'whatsapp' | 'instagram',
  identifier: string
): EncryptedData {
  return getEncryptionService().encryptToken(token, platform, identifier);
}

export function decryptToken(
  encryptedPayload: EncryptedData,
  platform: 'whatsapp' | 'instagram'
): { token: string; identifier: string; timestamp: number } {
  return getEncryptionService().decryptToken(encryptedPayload, platform);
}

export function verifyHMAC(
  payload: string,
  signature: string,
  secret: string
): boolean {
  return getEncryptionService().verifyHMAC(payload, signature, secret);
}

export default EncryptionService;