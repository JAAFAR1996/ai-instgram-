/**
 * ===============================================
 * Queue Infrastructure - Redis Streams/BullMQ
 * Production-ready message queue with Redis backend
 * ===============================================
 */

import { Queue, Worker, Job, QueueOptions, WorkerOptions } from 'bullmq';
import Redis from 'ioredis';
import { getLogger } from '../services/logger.js';

const log = getLogger({ component: 'queue' });

// Queue configuration
const QUEUE_CONFIG: QueueOptions = {
  connection: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379'),
    password: process.env.REDIS_PASSWORD,
    db: parseInt(process.env.REDIS_DB || '0'),
    maxRetriesPerRequest: 3,
    retryDelayOnFailover: 100,
    enableReadyCheck: false,
    lazyConnect: true,
  },
  defaultJobOptions: {
    removeOnComplete: 100,
    removeOnFail: 50,
    attempts: 3,
    backoff: {
      type: 'exponential',
      delay: 2000,
    },
  },
};

// Worker configuration
const WORKER_CONFIG: WorkerOptions = {
  connection: QUEUE_CONFIG.connection,
  concurrency: parseInt(process.env.QUEUE_CONCURRENCY || '5'),
  maxStalledCount: 1,
  stalledInterval: 30 * 1000,
};

// Queue instances
const queues = new Map<string, Queue>();
const workers = new Map<string, Worker>();

/**
 * Instagram webhook payload for queue processing
 */
export interface InstagramWebhookJob {
  merchantId: string;
  webhookEvent: any;
  signature: string;
  timestamp: number;
  headers: Record<string, string>;
}

/**
 * Utility message job payload
 */
export interface UtilityMessageJob {
  merchantId: string;
  recipientId: string;
  templateId: string;
  variables: Record<string, string>;
  messageType: string;
}

/**
 * Initialize queue system
 */
export async function initializeQueues(): Promise<void> {
  try {
    log.info('Initializing queue system...');

    // Create Instagram webhook queue
    const instagramQueue = new Queue('instagram-webhooks', QUEUE_CONFIG);
    queues.set('instagram-webhooks', instagramQueue);

    // Create utility message queue
    const utilityQueue = new Queue('utility-messages', QUEUE_CONFIG);
    queues.set('utility-messages', utilityQueue);

    // Test Redis connection
    const redis = new Redis(QUEUE_CONFIG.connection as any);
    await redis.ping();
    await redis.disconnect();

    log.info('Queue system initialized successfully');
  } catch (error: any) {
    log.error('Failed to initialize queue system:', error);
    throw error;
  }
}

/**
 * Get queue instance by name
 */
export function getQueue(queueName: string): Queue | null {
  return queues.get(queueName) || null;
}

/**
 * Enqueue Instagram webhook for processing
 */
export async function enqueueInstagramWebhook(
  payload: InstagramWebhookJob,
  priority: number = 0
): Promise<string> {
  const queue = getQueue('instagram-webhooks');
  if (!queue) {
    throw new Error('Instagram webhook queue not initialized');
  }

  const job = await queue.add('process-webhook', payload, {
    priority,
    delay: 0,
    removeOnComplete: 10,
    removeOnFail: 5,
  });

  log.info('Instagram webhook enqueued', {
    jobId: job.id,
    merchantId: payload.merchantId,
    timestamp: payload.timestamp,
  });

  return job.id || '';
}

/**
 * Enqueue utility message for sending
 */
export async function enqueueUtilityMessage(
  payload: UtilityMessageJob,
  priority: number = 0
): Promise<string> {
  const queue = getQueue('utility-messages');
  if (!queue) {
    throw new Error('Utility message queue not initialized');
  }

  const job = await queue.add('send-utility-message', payload, {
    priority,
    delay: 0,
    removeOnComplete: 10,
    removeOnFail: 5,
  });

  log.info('Utility message enqueued', {
    jobId: job.id,
    merchantId: payload.merchantId,
    recipientId: payload.recipientId,
    messageType: payload.messageType,
  });

  return job.id || '';
}

/**
 * Create and start a worker for processing jobs
 */
export function createWorker(
  queueName: string,
  processor: (job: Job) => Promise<any>
): Worker {
  const worker = new Worker(queueName, processor, WORKER_CONFIG);

  // Worker event handlers
  worker.on('completed', (job) => {
    log.info('Job completed', {
      queue: queueName,
      jobId: job.id,
      duration: Date.now() - job.processedOn!,
    });
  });

  worker.on('failed', (job, err) => {
    log.error('Job failed', {
      queue: queueName,
      jobId: job?.id,
      error: err.message,
      attempts: job?.attemptsMade,
    });
  });

  worker.on('stalled', (jobId) => {
    log.warn('Job stalled', {
      queue: queueName,
      jobId,
    });
  });

  worker.on('error', (err) => {
    log.error('Worker error', {
      queue: queueName,
      error: err.message,
    });
  });

  workers.set(queueName, worker);
  log.info(`Worker started for queue: ${queueName}`);

  return worker;
}

/**
 * Get queue statistics for monitoring
 */
export async function getQueueStats(queueName: string): Promise<any> {
  const queue = getQueue(queueName);
  if (!queue) {
    return null;
  }

  const [waiting, active, completed, failed, delayed] = await Promise.all([
    queue.getWaiting(),
    queue.getActive(),
    queue.getCompleted(),
    queue.getFailed(),
    queue.getDelayed(),
  ]);

  return {
    name: queueName,
    counts: {
      waiting: waiting.length,
      active: active.length,
      completed: completed.length,
      failed: failed.length,
      delayed: delayed.length,
    },
  };
}

/**
 * Gracefully shutdown all queues and workers
 */
export async function shutdownQueues(): Promise<void> {
  log.info('Shutting down queue system...');

  // Close all workers
  const workerPromises = Array.from(workers.values()).map(async (worker) => {
    try {
      await worker.close();
      log.debug(`Worker ${worker.name} closed`);
    } catch (error: any) {
      log.error(`Error closing worker ${worker.name}:`, error);
    }
  });

  // Close all queues
  const queuePromises = Array.from(queues.values()).map(async (queue) => {
    try {
      await queue.close();
      log.debug(`Queue ${queue.name} closed`);
    } catch (error: any) {
      log.error(`Error closing queue ${queue.name}:`, error);
    }
  });

  await Promise.all([...workerPromises, ...queuePromises]);
  
  queues.clear();
  workers.clear();

  log.info('Queue system shutdown completed');
}

/**
 * Health check for queue system
 */
export async function checkQueueHealth(): Promise<{ healthy: boolean; details: any }> {
  try {
    const redis = new Redis(QUEUE_CONFIG.connection as any);
    await redis.ping();
    await redis.disconnect();

    const stats = await Promise.all([
      getQueueStats('instagram-webhooks'),
      getQueueStats('utility-messages'),
    ]);

    return {
      healthy: true,
      details: {
        queues: stats.filter(s => s !== null),
        workers: Array.from(workers.keys()),
      },
    };
  } catch (error: any) {
    return {
      healthy: false,
      details: {
        error: error.message,
        queues: [],
        workers: [],
      },
    };
  }
}