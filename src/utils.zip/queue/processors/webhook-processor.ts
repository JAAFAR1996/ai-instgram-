/**
 * ===============================================
 * Webhook Job Processor
 * Async processing for webhook events
 * ===============================================
 */

import type { Job } from 'bullmq';
import { InstagramWebhookHandler } from '../../services/instagram-webhook.js';
import { getPool } from '../../db/index.js';
import * as MerchantRepo from '../../repos/merchant.repo.js';
import { getLogger } from '../../services/logger.js';
import { telemetry } from '../../services/telemetry.js';
import { createWorker, type InstagramWebhookJob } from '../index.js';


/**
 * Instagram webhook job processor
 */
export async function processInstagramWebhookJob(job: Job<InstagramWebhookJob>): Promise<void> {
  const startTime = Date.now();
  const { merchantId, webhookEvent, signature, timestamp, headers } = job.data;
  const logger = getLogger({ component: 'webhook-processor' });
  const pool = getPool();

  try {
    logger.info('Processing Instagram webhook job', {
      jobId: job.id,
      merchantId,
      eventType: webhookEvent.object,
      entryCount: webhookEvent.entry?.length || 0,
    });

    // Validate merchant exists and is active
    const merchant = await MerchantRepo.getMerchantById(pool, merchantId);
    if (!merchant) {
      throw new Error(`Merchant not found: ${merchantId}`);
    }
    
    if (merchant.status !== 'active') {
      throw new Error(`Merchant is inactive: ${merchantId}`);
    }

    // Initialize Instagram webhook handler
    const handler = new InstagramWebhookHandler();

    // Process webhook event
    const result = await handler.processWebhookEvent(
      webhookEvent,
      merchantId,
      {
        'x-hub-signature-256': signature,
        'content-type': headers['content-type'] || 'application/json',
      }
    );

    if (result.success) {
      const processingTime = Date.now() - startTime;
      
      logger.info('Webhook processing completed successfully', {
        jobId: job.id,
        merchantId,
        eventsProcessed: result.eventsProcessed,
        messagesProcessed: result.messagesProcessed,
        processingTimeMs: processingTime,
      });

      // Record successful processing telemetry
      telemetry.recordMetaRequest(
        'instagram',
        'webhook_worker',
        200,
        processingTime,
        false
      );
    } else {
      const processingTime = Date.now() - startTime;
      
      logger.error('Webhook processing failed in worker', {
        jobId: job.id,
        merchantId,
        errors: result.errors,
        processingTimeMs: processingTime,
      });

      // Record failed processing telemetry
      telemetry.recordMetaRequest(
        'instagram',
        'webhook_worker',
        500,
        processingTime,
        false
      );

      // Throw error to trigger job retry
      throw new Error(`Webhook processing failed: ${result.errors?.join(', ')}`);
    }
  } catch (error: any) {
    const processingTime = Date.now() - startTime;
    
    logger.error('Instagram webhook worker error', {
      jobId: job.id,
      merchantId,
      error: error.message,
      processingTimeMs: processingTime,
      attempt: job.attemptsMade,
    });

    // Record error telemetry
    telemetry.recordMetaRequest(
      'instagram',
      'webhook_worker',
      500,
      processingTime,
      false
    );

    // Re-throw to allow BullMQ to handle retries
    throw error;
  }
}


/**
 * Initialize Instagram webhook worker
 */
export function startInstagramWebhookWorker(): void {
  createWorker('instagram-webhooks', processInstagramWebhookJob);
  const logger = getLogger({ component: 'webhook-processor' });
  logger.info('Instagram webhook worker started');
}