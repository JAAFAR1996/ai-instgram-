import { diag, DiagConsoleLogger, DiagLogLevel } from '@opentelemetry/api';
import { MeterProvider } from '@opentelemetry/sdk-metrics';
// If you export to Prometheus, wire your chosen exporter here.

let _inited = false;
let meterProvider: MeterProvider | null = null;

export async function initTelemetry(): Promise<void> {
  if (_inited) return;
  diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.ERROR);
  meterProvider = new MeterProvider();
  _inited = true;
}

export function getMeter(name = 'ai-sales-platform') {
  if (!meterProvider) throw new Error('telemetry not initialized');
  return meterProvider.getMeter(name);
}

// Convenience counters
const counters = new Map<string, ReturnType<ReturnType<typeof getMeter>['createCounter']>>();
export function counter(name: string, description?: string) {
  if (!counters.has(name)) {
    const m = getMeter();
    counters.set(name, m.createCounter(name, { description }));
  }
  return counters.get(name)!;
}

/* back-compat shim */
export const telemetry = {
  recordMetaRequest(platform: 'instagram'|'whatsapp', endpoint: string, status: number, latencyMs: number, rateLimited = false) {
    try {
      counter('meta_requests_total','Total Meta API requests').add(1,{ platform, endpoint, status: String(status) });
      getMeter().createHistogram('meta_latency_ms',{ description:'Meta API request latency' }).record(latencyMs,{ platform, endpoint, status:String(status) });
      if (rateLimited) counter('meta_rate_limited_total','Meta API rate limit hits').add(1,{ platform, endpoint });
    } catch {}
  },
  recordRateLimitStoreFailure(platform: 'instagram'|'whatsapp', endpoint: string) {
    try {
      counter('rate_limit_store_failures_total','Redis rate limit store failures').add(1,{ platform, endpoint });
    } catch {}
  },
  trackEvent(name: string, props: Record<string, unknown> = {}) {
    try {
      counter('events_total','Custom events').add(1,{ name, ...(props as any) });
    } catch {}
  },
};
