/**
 * ===============================================
 * Database Migration System - Production Ready
 * Handles database schema migrations and rollbacks
 * ===============================================
 */

import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';
import { getLogger } from '../services/logger.js';
import { getPool } from '../db/index.js';

const log = getLogger({ component: 'database-migration' });

/**
 * Run database migrations using production-ready pattern
 */
export async function runDatabaseMigrations(): Promise<void> {
  const currentPool = getPool();
  
  // Check for multiple migration directories
  const migrationDirs = [
    join(process.cwd(), 'migrations'),
    join(process.cwd(), 'src/database/migrations'),
    join(process.cwd(), 'src/migrations')
  ];

  let migrationDir: string | null = null;
  for (const dir of migrationDirs) {
    try {
      const fs = await import('fs');
      if (fs.existsSync(dir)) {
        migrationDir = dir;
        break;
      }
    } catch {
      // Directory doesn't exist
    }
  }

  if (!migrationDir) {
    log.warn('No migration directory found, skipping migrations');
        return;
      }

  log.info(`Running migrations from: ${migrationDir}`);

  const files = readdirSync(migrationDir)
    .filter(f => f.endsWith('.sql'))
    .sort(); // Ensure chronological order

  if (files.length === 0) {
    log.info('No migration files found');
    return;
  }

  const client = await currentPool.connect();
  try {
    // Create migrations tracking table
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migrations (
        name TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    for (const file of files) {
      // Check if migration already applied
      const { rows } = await client.query(
        'SELECT 1 FROM _migrations WHERE name = $1',
        [file]
      );
      
      if (rows.length > 0) {
        log.info(`⏭️  Migration already applied: ${file}`);
        continue;
      }

      const sql = readFileSync(join(migrationDir, file), 'utf8');
      log.info(`🔄 Running migration: ${file}`);
      
      await client.query('BEGIN');
      try {
        await client.query(sql);
        // Record migration as applied
        await client.query('INSERT INTO _migrations (name) VALUES ($1)', [file]);
        await client.query('COMMIT');
        log.info(`✅ Migration completed: ${file}`);
      } catch (error) {
        await client.query('ROLLBACK');
        log.error(`❌ Migration failed: ${file}`, error);
        throw error;
      }
    }

    log.info('✅ All migrations completed successfully');
  } catch (error) {
    log.error('❌ Migration process failed:', error);
    throw error;
  } finally {
    client.release();
    }
  }

  /**
   * Get migration status
   */
export async function getMigrationStatus(): Promise<{
    total: number;
    executed: number;
    pending: number;
  migrations: any[];
}> {
  const currentPool = getPool();
  const client = await currentPool.connect();
  
  try {
    // Ensure migrations table exists
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migrations (
        name TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Get migration directories
    const migrationDirs = [
      join(process.cwd(), 'migrations'),
      join(process.cwd(), 'src/database/migrations'),
      join(process.cwd(), 'src/migrations')
    ];

    let migrationDir: string | null = null;
    for (const dir of migrationDirs) {
      try {
        const fs = await import('fs');
        if (fs.existsSync(dir)) {
          migrationDir = dir;
          break;
        }
      } catch {
        // Directory doesn't exist
      }
    }

    if (!migrationDir) {
      return { total: 0, executed: 0, pending: 0, migrations: [] };
    }

    const allFiles = readdirSync(migrationDir)
      .filter(f => f.endsWith('.sql'))
      .sort();

    const { rows: executedMigrations } = await client.query(
      'SELECT name, applied_at FROM _migrations ORDER BY applied_at'
    );

    const migrations = allFiles.map(file => {
      const executed = executedMigrations.find((m: any) => m.name === file);
      return {
        name: file,
        status: executed ? 'executed' : 'pending',
        applied_at: executed?.applied_at || null
      };
    });

    return {
      total: allFiles.length,
      executed: executedMigrations.length,
      pending: allFiles.length - executedMigrations.length,
      migrations
    };
  } finally {
    client.release();
    }
  }

  /**
 * Create migration tracking table
 */
export async function createMigrationTable(): Promise<void> {
  const currentPool = getPool();
  const client = await currentPool.connect();
  
  try {
    await client.query(`
      CREATE TABLE IF NOT EXISTS _migrations (
        name TEXT PRIMARY KEY,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    log.info('✅ Migration tracking table created');
  } finally {
    client.release();
    }
  }

  /**
 * Rollback last migration
 */
export async function rollbackMigration(): Promise<void> {
  const currentPool = getPool();
  const client = await currentPool.connect();
  
  try {
    // Get last executed migration
    const { rows } = await client.query(
      'SELECT name FROM _migrations ORDER BY applied_at DESC LIMIT 1'
    );
    
    if (rows.length === 0) {
      log.info('ℹ️ No migrations to rollback');
      return;
    }

    const lastMigration = rows[0].name;
    log.info(`🔄 Rolling back migration: ${lastMigration}`);
    
    // Remove migration record
    await client.query('DELETE FROM _migrations WHERE name = $1', [lastMigration]);
    
    log.info(`✅ Migration rolled back: ${lastMigration}`);
  } finally {
    client.release();
  }
}

// Export functions for backward compatibility
export const migrate = runDatabaseMigrations;
export const rollback = rollbackMigration;

// Default export
export default {
  runDatabaseMigrations,
  getMigrationStatus,
  createMigrationTable,
  rollbackMigration
};