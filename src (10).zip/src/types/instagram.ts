/**
 * Instagram-specific type definitions
 */

export type MessagingProduct = 'instagram';

export interface QuickReply {
  content_type: 'text';
  title: string;
  payload?: string;
}

export interface InstagramMessagePayload {
  messaging_product: MessagingProduct; // 'instagram'
  recipient: { id: string };
  messaging_type: 'RESPONSE' | 'UPDATE' | 'MESSAGE_TAG';
  message: {
    text?: string;
    attachment?: { type: string; payload: unknown };
    quick_replies?: QuickReply[];
  };
}

export interface SendMessageRequest {
  recipientId: string;
  text?: string;
  attachment?: { type: string; payload: unknown };
  quickReplies?: QuickReply[];
  messagingType?: 'RESPONSE' | 'UPDATE' | 'MESSAGE_TAG';
}

export interface InstagramAPICredentials {
  accessToken: string;
  pageId: string;
  businessAccountId: string;
  appSecret?: string;
  webhookVerifyToken?: string;
}

export interface InstagramAPIResponse {
  success: boolean;
  messageId?: string;
  rateLimitRemaining?: number;
  error?: string;
}

export interface SendResult {
  success: boolean;
  messageId?: string;
  deliveryStatus: 'sent' | 'failed';
  timestamp: Date;
  error?: string;
}

// قاعدة لأنواع الصفوف التي يطلبها sql<T> حيث T يمتلك index signature
export type DatabaseRow = { [key: string]: unknown };
export type DBRow<T extends object> = T & DatabaseRow;

export interface InstagramContext {
  merchantId: string;
  customerId: string;
  platform: 'instagram';
  stage: string;
  cart: Record<string, unknown>[];
  preferences: Record<string, unknown>;
  conversationHistory: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
    metadata?: Record<string, unknown>;
  }>;
  customerProfile?: {
    name?: string;
    phone?: string;
    instagram?: string;
    previousOrders: number;
    averageOrderValue: number;
    preferredCategories: string[];
    lastInteraction: Date;
  };
  merchantSettings?: {
    businessName: string;
    businessCategory: string;
    workingHours: Record<string, unknown>;
    paymentMethods: string[];
    deliveryFees: Record<string, unknown>;
    autoResponses: Record<string, unknown>;
  };
}

export interface MediaContent {
  format: string;
  originalFileName?: string;
  metadata?: {
    duration?: number;
    fileSize?: number;
    dimensions?: {
      width: number;
      height: number;
    };
    format?: string;
    originalFileName?: string;
    aiAnalysis?: {
      description?: string;
      objects?: string[];
      colors?: string[];
      text?: string;
      sentiment?: 'positive' | 'neutral' | 'negative';
      isProductImage?: boolean;
      suggestedTags?: string[];
    };
  };
}

export interface WebhookEvent {
  field: string;
  value: {
    id: string;
    media?: {
      id: string;
      media_product_type: 'feed' | 'story' | 'reels' | 'ad';
    };
  };
}

export interface JobData {
  merchantId: string;
  [key: string]: unknown;
}

export interface BullJob {
  data: JobData;
  attemptsMade?: number;
  opts?: {
    attempts?: number;
    delay?: number;
  };
}

export interface PerformanceMetrics {
  endpoint: string;
  method: string;
  responseTime: number;
  statusCode: number;
  timestamp: Date;
  merchantId?: string;
  errorMessage?: string;
}

export interface LogContext {
  merchantId?: string;
  endpoint?: string;
  event?: string;
  [key: string]: unknown;
}

export interface QualityStatus {
  status: 'EXCELLENT' | 'GOOD' | 'MEDIUM' | 'LOW' | 'CRITICAL';
}