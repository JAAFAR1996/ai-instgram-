// src/infrastructure/db/sql-compat.ts
import type { Pool, QueryResult } from 'pg';

// واجهة متوافقة مع postgres.js المستعملة عندك
export interface SqlFunction {
  <T extends Record<string, any> = Record<string, any>>(strings: TemplateStringsArray, ...values: any[]): Promise<T[]>;
  unsafe: <T extends Record<string, any> = Record<string, any>>(arg: TemplateStringsArray | string, ...rest: any[]) => Promise<T[]>;
  // معاملات معاملات مبسطة (no-op wrappers)
  begin: <T = unknown>(fn: (sql: SqlFunction) => Promise<T>) => Promise<T>;
  commit: () => Promise<void>;
  rollback: () => Promise<void>;
  transaction: <T = unknown>(fn: (sql: SqlFunction) => Promise<T>) => Promise<T>;
}

function compile(strings: TemplateStringsArray, values: any[]) {
  const text = strings.reduce((acc, s, i) => acc + s + (i < values.length ? `$${i + 1}` : ''), '');
  return { text, values };
}

export function buildSqlCompat(pool: Pool): SqlFunction {
  const core = async <T extends Record<string, any> = Record<string, any>>(strings: TemplateStringsArray, ...values: any[]): Promise<T[]> => {
    const { text, values: params } = compile(strings, values);
    const result = await pool.query(text, params);
    return result.rows;
  };

  const unsafe = async <T extends Record<string, any> = Record<string, any>>(arg: TemplateStringsArray | string, ...rest: any[]): Promise<T[]> => {
    if (typeof arg === 'string') {
      const text: string = arg;
      const params = rest[0] ?? [];
      const result = await pool.query(text, params);
      return result.rows;
    } else {
      // tagged template
      const strings: TemplateStringsArray = arg;
      const { text, values } = compile(strings, rest);
      const result = await pool.query(text, values);
      return result.rows;
    }
  };

  // معاملات مبسطة: ننفذ fn مباشرةً بنفس sql
  const wrapTx = async <T>(fn: (sql: SqlFunction) => Promise<T>): Promise<T> => fn(sql);

  const sql = Object.assign(core, {
    unsafe,
    begin: wrapTx,
    commit: async () => {},
    rollback: async () => {},
    transaction: wrapTx
  });
  return sql;
}