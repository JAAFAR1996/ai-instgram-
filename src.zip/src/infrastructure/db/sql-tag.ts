// src/infrastructure/db/sql-tag.ts
import type { Pool } from 'pg';

export type SQLTag = (strings: TemplateStringsArray, ...values: any[]) => Promise<any[]>;

function compileTemplate(strings: TemplateStringsArray, values: any[]) {
  // يبني نص استعلام بـ $1, $2 ... ويجمع values بالترتيب
  const text = strings.reduce((acc, s, i) => acc + s + (i < values.length ? `$${i + 1}` : ''), '');
  return { text, values };
}

/**
 * يبني sql`` tag فوق Pool.query بحيث:
 *   await sql`SELECT ... WHERE id = ${id}::uuid`
 * يرجّع rows مباشرةً (array)
 */
export function buildSQLTag(pool: Pool): SQLTag {
  return async (strings: TemplateStringsArray, ...values: any[]) => {
    const { text, values: params } = compileTemplate(strings, values);
    const { rows } = await pool.query(text, params);
    return rows;
  };
}