/**
 * ===============================================
 * SQL Template System - Production Ready
 * نظام موحد للتعامل مع قواعد البيانات مع حماية من SQL Injection
 * ===============================================
 */

// ✅ واجهة موحّدة مع sql-compat وتفكيك أي اختلافات قديمة
import type { Pool } from 'pg';
export type { SqlFunction } from '../infrastructure/db/sql-compat.js';
export { buildSqlCompat as getSql } from '../infrastructure/db/sql-compat.js';
export { buildSqlCompat as getSQLFromPool } from '../infrastructure/db/sql-compat.js';

// إن وُجدت دوال أو أنواع قديمة هنا كانت مكسورة، احذفها.
// لا تُعرّف begin/commit محلياً. كل شيء يمر عبر sql-compat.

// Legacy compatibility
export type Sql = import('../infrastructure/db/sql-compat.js').SqlFunction;