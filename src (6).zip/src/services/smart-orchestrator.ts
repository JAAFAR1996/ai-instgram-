import { classifyAndExtract, type IntentResult } from '../nlp/intent.js';
import { kbSearch } from '../kb/search.js';
import { searchProduct } from '../repos/product-search.js';
import { getDatabase } from '../db/adapter.js';

export interface OrchestratorOptions {
  askAtMostOneFollowup?: boolean;
  session?: Record<string, unknown> | null; // conversations.session_data
}

export interface OrchestratorResult {
  text: string;
  intent: IntentResult['intent'];
  confidence: number;
  entities: IntentResult['entities'];
  decision_path: string[];
  kb_source?: { id: string; title: string };
  session_patch?: Record<string, unknown>;
}

export async function orchestrate(
  merchantId: string,
  username: string,
  messageText: string,
  options: OrchestratorOptions = { askAtMostOneFollowup: true }
): Promise<OrchestratorResult> {
  const db = getDatabase();
  const sql = db.getSQL();

  // Load merchant hints (ai_config)
  const rows = await sql<{ ai_config: any; business_name: string; business_category: string | null }>`
    SELECT ai_config, business_name, business_category FROM merchants WHERE id = ${merchantId}::uuid LIMIT 1
  `;
  const merchant = rows[0] || { ai_config: {}, business_name: 'متجرنا', business_category: null };
  const aiCfg = merchant.ai_config || {};

  const hints = {
    synonyms: aiCfg?.synonyms || { 'جزمه': ['حذاء','بوت'] },
    categories: aiCfg?.categories || [],
    brands: aiCfg?.brands || [],
    colors: aiCfg?.colors || [],
    genders: aiCfg?.genders || undefined,
    sizeAliases: aiCfg?.sizeAliases || {},
    customEntities: aiCfg?.customEntities || {},
  } as any;

  // Merge session memory into entity extraction (do not override explicit message extraction)
  const analysis = classifyAndExtract(messageText, hints);
  const session = options.session || {};
  const sessionEntities = {
    category: (session as any)?.category || undefined,
    gender: (session as any)?.gender || undefined,
    size: (session as any)?.size || undefined,
    color: (session as any)?.color || undefined,
    brand: (session as any)?.brand || undefined,
  } as Partial<IntentResult['entities']>;
  analysis.entities = {
    ...sessionEntities,
    ...analysis.entities,
  };
  const decision: string[] = [`intent=${analysis.intent}`, `confidence=${analysis.confidence.toFixed(2)}`];

  // Small talk
  if (analysis.intent === 'SMALL_TALK') {
    const text = `هلا ${username}! شلونك؟ خلي أعرف شنو تبحث عنه اليوم 🌟`;
    return { text, intent: analysis.intent, confidence: analysis.confidence, entities: analysis.entities, decision_path: decision };
  }

  // Pricing / Inventory via SQL
  if (analysis.intent === 'PRICE' || analysis.intent === 'INVENTORY') {
    // Check missing critical property
    const needsCategory = !analysis.entities.category;
    const clarifyAttempts = Number((session as any)?.clarify_attempts?.category || 0);
    if (needsCategory && options.askAtMostOneFollowup) {
      if (clarifyAttempts < 2) {
        const text = 'تريد شنو بالضبط؟ قميص، حذاء، بنطلون؟';
        decision.push('clarify=category');
        return {
          text,
          intent: analysis.intent,
          confidence: analysis.confidence,
          entities: analysis.entities,
          decision_path: decision,
          session_patch: {
            clarify_attempts: {
              ...(session as any)?.clarify_attempts,
              category: clarifyAttempts + 1
            }
          }
        };
      }
      // Max attempts reached → proceed with best approximate match
      decision.push('clarify=max_reached');
    }

    const q = messageText;
    const res = await searchProduct(merchantId, q, analysis.entities, hints.synonyms);
    if (res.top) {
      const top = res.top!;
      const price = Math.round(top.sale_price_amount ?? top.price_amount);
      const cur = top.price_currency || 'IQD';
      const avail = top.stock_quantity > 0 ? 'متوفر' : 'غير متوفر حالياً';
      const altColors = res.alternatives.slice(0, 2).map(a => a.category && a.category !== top.category ? a.category : null).filter(Boolean);
      const extra = altColors.length ? ` بدائل: ${altColors.join('/')} ` : '';
      const text = `سعر ${top.name_ar}${analysis.entities.size ? ` مقاس ${analysis.entities.size}` : ''} يبدأ من ${price} ${cur}. الحالة: ${avail}.${extra}تختار شنو؟`;
      decision.push('sql=hit');
      return {
        text,
        intent: analysis.intent,
        confidence: analysis.confidence,
        entities: analysis.entities,
        decision_path: decision,
        session_patch: {
          last_product_id: top.id,
          // Persist discovered attributes for future turns
          ...(analysis.entities.gender ? { gender: analysis.entities.gender } : {}),
          ...(analysis.entities.size ? { size: analysis.entities.size } : {}),
          ...(analysis.entities.color ? { color: analysis.entities.color } : {}),
          ...(analysis.entities.category ? { category: analysis.entities.category } : {})
        }
      };
    }
    decision.push('sql=miss');
    const text = 'ما لقيت نفس المواصفات. تحب أشوف بدائل قريبة؟';
    return {
      text,
      intent: analysis.intent,
      confidence: analysis.confidence,
      entities: analysis.entities,
      decision_path: decision,
      session_patch: {
        ...(analysis.entities.gender ? { gender: analysis.entities.gender } : {}),
        ...(analysis.entities.size ? { size: analysis.entities.size } : {}),
        ...(analysis.entities.color ? { color: analysis.entities.color } : {}),
        ...(analysis.entities.category ? { category: analysis.entities.category } : {})
      }
    };
  }

  // FAQ via KB search
  if (analysis.intent === 'FAQ') {
    const hits = await kbSearch(merchantId, messageText, 3);
    if (hits.length > 0) {
      const top = hits[0]!;
      const snippet = top.chunk.trim().slice(0, 280);
      const text = `حسب سياسة «${top.title}»: ${snippet}${snippet.length >= 280 ? '…' : ''}`;
      decision.push('rag=hit');
      return {
        text,
        intent: analysis.intent,
        confidence: analysis.confidence,
        entities: analysis.entities,
        decision_path: decision,
        kb_source: { id: top.id, title: top.title },
        session_patch: { last_kb_doc_id: top.id }
      };
    }
    decision.push('rag=miss');
    const text = 'أحتاج أتأكد من السياسة. أرجعلك بالتفاصيل حالاً بعد المراجعة.';
    return { text, intent: analysis.intent, confidence: analysis.confidence, entities: analysis.entities, decision_path: decision };
  }

  // OTHER: short guidance
  const text = `أوكي! حتى أساعدك بسرعة، خبرني شنو المنتج والمقاس/اللون إذا تريده.`;
  return {
    text,
    intent: analysis.intent,
    confidence: analysis.confidence,
    entities: analysis.entities,
    decision_path: decision,
    session_patch: {
      ...(analysis.entities.gender ? { gender: analysis.entities.gender } : {}),
      ...(analysis.entities.size ? { size: analysis.entities.size } : {}),
      ...(analysis.entities.color ? { color: analysis.entities.color } : {}),
      ...(analysis.entities.category ? { category: analysis.entities.category } : {})
    }
  };
}
