/**
 * ===============================================
 * Redis Startup Module
 * Handles Redis integration and queue initialization
 * ===============================================
 */

import { Pool } from 'pg';
import { getLogger } from '../services/logger.js';
import { getRedisConnectionManager } from '../services/RedisConnectionManager.js';
import { ProductionQueueManager } from '../services/ProductionQueueManager.js';
import { RedisEnvironment } from '../config/RedisConfigurationFactory.js';
const Environment = RedisEnvironment;

const log = getLogger({ component: 'redis-startup' });

// Global instances (simplified)
let queueManager: ProductionQueueManager | null = null;
let initializationResult: RedisIntegrationResult | null = null;

export interface RedisIntegrationResult {
  success: boolean;
  mode: 'active' | 'fallback' | 'disabled';
  queueManager?: ProductionQueueManager;
  error?: string;
  reason?: string;
}

/**
 * Initialize Redis integration (simplified version)
 */
export async function initializeRedisIntegration(pool: Pool): Promise<RedisIntegrationResult> {
  if (initializationResult) {
    log.info('Redis integration already initialized, returning cached result');
    return initializationResult;
  }

  const redisUrl = process.env.REDIS_URL;
  if (!redisUrl) {
    log.warn('REDIS_URL not configured, skipping Redis integration');
    initializationResult = {
      success: false,
      mode: 'disabled',
      reason: 'no_redis_url',
      error: 'REDIS_URL environment variable not set'
    };
    return initializationResult;
  }

  try {
    log.info('🔄 Initializing Redis integration...');
    
    // Simple Redis connection test via manager
    const connectionManager = getRedisConnectionManager();
    
    // Try to initialize queue manager
    const { getPool } = await import('../db/index.js');
    const { Environment } = await import('../config/RedisConfigurationFactory.js');
    const environment = process.env.NODE_ENV === 'production' ? Environment.PRODUCTION : Environment.DEVELOPMENT;
    const dbPool = getPool();
    
    queueManager = new ProductionQueueManager(redisUrl, log, environment, dbPool);
    const queueResult = await queueManager.initialize();
    
    if (queueResult.success) {
      log.info('✅ Redis integration initialized successfully');
      initializationResult = {
        success: true,
        mode: 'active',
        queueManager: queueManager
      };
    } else {
      log.warn('⚠️ Redis queue initialization failed, using fallback mode');
      initializationResult = {
        success: false,
        mode: 'fallback',
        error: queueResult.error,
        reason: 'queue_init_failed'
      };
    }

    return initializationResult;
  } catch (error: any) {
    log.error('❌ Redis integration initialization failed', error);
    
    initializationResult = {
      success: false,
      mode: 'disabled',
      error: error.message,
      reason: 'initialization_error'
    };
    
    return initializationResult;
  }
}

/**
 * Get the Redis connection manager (simplified)
 */
export function getRedisManager() {
  return getRedisConnectionManager();
}

/**
 * Get the current initialization result
 */
export function getRedisIntegrationStatus(): RedisIntegrationResult | null {
  return initializationResult;
}

/**
 * Check if Redis integration is healthy
 */
export function isRedisHealthy(): boolean {
  return initializationResult?.success === true && initializationResult.mode === 'active';
}

/**
 * Get queue manager if available (simplified)
 */
export function getQueueManager() {
  return queueManager;
}

/**
 * Cleanup Redis connections gracefully (simplified)
 */
export async function closeRedisConnections(): Promise<void> {
  try {
    if (queueManager) {
      await queueManager.gracefulShutdown();
    }
    
    const connectionManager = getRedisConnectionManager();
    await connectionManager.closeAllConnections();
    
    log.info('Redis connections closed');
  } catch (error: any) {
    log.error('Error closing Redis connections:', error);
  }
}