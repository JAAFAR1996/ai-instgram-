
        CREATE TABLE IF NOT EXISTS test_concurrent_migration (
          id SERIAL PRIMARY KEY,
          name VARCHAR(100)
        );
      