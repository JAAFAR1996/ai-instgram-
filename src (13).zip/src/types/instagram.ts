export type MessagingProduct = 'instagram';

export interface InstagramAPICredentials {
  // تُستخدم صيغ متعددة عبر الخدمات
  accessToken?: string;
  pageAccessToken?: string;
  businessAccountId?: string;
  pageId?: string;
  appSecret?: string;
  webhookVerifyToken?: string;
  tokenExpiresAt?: Date; // مطلوبة في عدة خدمات
}
// توافقاً مع كود oauth
export type InstagramOAuthCredentials = InstagramAPICredentials;

export interface QuickReply {
  title: string;
  payload: unknown;
}

export interface InstagramAPIResponse {
  success: boolean;
  // بعض الخدمات تقرأ id مباشرةً
  id?: string;
  messageId?: string;
  error?: string;
}

export interface SendMessageRequest {
  // شائعة في الكود: messagingType / messageType / content / text / recipientId / attachment / quickReplies
  messagingType?: 'RESPONSE' | 'UPDATE' | 'MESSAGE_TAG';
  messageType?: 'text' | 'image' | 'template';
  content?: string; // يُستخدم لتمرير JSON template أحياناً
  text?: string;    // نص مباشر
  recipientId?: string;
  attachment?: { type: string; payload: unknown };
  quickReplies?: QuickReply[];
}

export interface InstagramMessagePayload {
  messaging_product: MessagingProduct; // 'instagram'
  recipient: { id: string };
  message: {
    text?: string;
    attachment?: { type: string; payload: unknown };
    quick_replies?: QuickReply[];
  };
}

export interface SendResult {
  success: boolean;
  messageId?: string;
  platformMessageId?: string;
  error?: string;
  // تُستخدم في instagram-message-sender.ts
  deliveryStatus?: 'sent' | 'failed';
  timestamp?: Date;
}

// حمولة الويبهوك (مبسّطة لتكفي الاستعمال)
export interface IGWebhookPayload {
  object: 'instagram';
  entry: Array<Record<string, unknown>>;
}

// لتوافق instagram-setup.ts
export interface BusinessAccountInfo {
  id: string;
  username?: string; // نجعلها اختيارية لتجنّب أخطاء exactOptionalPropertyTypes
  name?: string;
  profile_picture_url?: string;
  followers_count?: number;
  media_count?: number;
}

// صف عام للنتائج من قاعدة البيانات (يُستعمل مع DBRow)
export type DBRow<T> = T & Record<string, unknown>;

export interface InstagramContext {
  merchantId: string;
  customerId: string;
  platform: 'instagram';
  stage: string;
  cart: Record<string, unknown>[];
  preferences: Record<string, unknown>;
  conversationHistory: Array<{
    role: 'user' | 'assistant' | 'system';
    content: string;
    timestamp: Date;
    metadata?: Record<string, unknown>;
  }>;
  customerProfile?: {
    name?: string;
    phone?: string;
    instagram?: string;
    previousOrders: number;
    averageOrderValue: number;
    preferredCategories: string[];
    lastInteraction: Date;
  };
  merchantSettings?: {
    businessName: string;
    businessCategory: string;
    workingHours: Record<string, unknown>;
    paymentMethods: string[];
    deliveryFees: Record<string, unknown>;
    autoResponses: Record<string, unknown>;
  };
}

export interface MediaContent {
  format: string;
  originalFileName?: string;
  metadata?: {
    duration?: number;
    fileSize?: number;
    dimensions?: {
      width: number;
      height: number;
    };
    format?: string;
    originalFileName?: string;
    aiAnalysis?: {
      description?: string;
      objects?: string[];
      colors?: string[];
      text?: string;
      sentiment?: 'positive' | 'neutral' | 'negative';
      isProductImage?: boolean;
      suggestedTags?: string[];
    };
  };
}

export interface WebhookEvent {
  field: string;
  value: {
    id: string;
    media?: {
      id: string;
      media_product_type: 'feed' | 'story' | 'reels' | 'ad';
    };
  };
}

export interface JobData {
  merchantId: string;
  [key: string]: unknown;
}

export interface BullJob {
  data: JobData;
  attemptsMade?: number;
  opts?: {
    attempts?: number;
    delay?: number;
  };
}

export interface PerformanceMetrics {
  endpoint: string;
  method: string;
  responseTime: number;
  statusCode: number;
  timestamp: Date;
  merchantId?: string;
  errorMessage?: string;
}

export interface LogContext {
  merchantId?: string;
  endpoint?: string;
  event?: string;
  [key: string]: unknown;
}

export interface QualityStatus {
  status: 'EXCELLENT' | 'GOOD' | 'MEDIUM' | 'LOW' | 'CRITICAL';
}