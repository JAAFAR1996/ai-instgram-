// نوع بسيط لسياق السجلات
type LogContext = Record<string, unknown>;
